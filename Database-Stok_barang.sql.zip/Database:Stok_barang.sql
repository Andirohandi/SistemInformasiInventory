-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 02, 2014 at 08:26 PM
-- Server version: 5.1.30
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stok_barang`
--

-- --------------------------------------------------------

--
-- Table structure for table `bkb`
--

CREATE TABLE IF NOT EXISTS `bkb` (
  `id_nm` int(10) NOT NULL,
  `no_bkb` varchar(20) NOT NULL,
  `no_val` varchar(20) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `kodebb` varchar(50) NOT NULL,
  `sat` int(4) NOT NULL,
  `unit` int(20) NOT NULL,
  `tonage` int(15) NOT NULL,
  `tgl_bkb` varchar(20) NOT NULL,
  `klr_ke` varchar(20) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `ket` varchar(500) NOT NULL,
  PRIMARY KEY (`id_nm`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bkb`
--

INSERT INTO `bkb` (`id_nm`, `no_bkb`, `no_val`, `kode`, `kodebb`, `sat`, `unit`, `tonage`, `tgl_bkb`, `klr_ke`, `kategori`, `ket`) VALUES
(1, 'BKB.14.10.0001', '', 'XA001', 'XA001', 50, 1200, 60000, '02-Okt-2014', 'Produksi WB', 'Bahan Baku', '');

-- --------------------------------------------------------

--
-- Table structure for table `bkbtm`
--

CREATE TABLE IF NOT EXISTS `bkbtm` (
  `id_nm` int(10) NOT NULL,
  `no_bkbtm` varchar(20) NOT NULL,
  `tgl_bkbtm` varchar(20) NOT NULL,
  `no_bkb` varchar(20) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `kodebb` varchar(50) NOT NULL,
  `sat` int(10) NOT NULL,
  `unit` int(15) NOT NULL,
  `tonage` int(15) NOT NULL,
  `kategori` varchar(15) NOT NULL,
  `ket` text NOT NULL,
  `no_val` int(10) NOT NULL,
  PRIMARY KEY (`id_nm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bkbtm`
--


-- --------------------------------------------------------

--
-- Table structure for table `btb`
--

CREATE TABLE IF NOT EXISTS `btb` (
  `id_nm` int(10) NOT NULL AUTO_INCREMENT,
  `no_btb` varchar(20) NOT NULL,
  `no_sj` varchar(15) NOT NULL,
  `supplier` varchar(50) NOT NULL,
  `no_po` varchar(20) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `kodebb` varchar(50) NOT NULL,
  `packing` varchar(10) NOT NULL,
  `sat` int(4) NOT NULL,
  `unit` int(10) NOT NULL,
  `tonage` int(15) NOT NULL,
  `hrg_sat` int(15) NOT NULL,
  `hrg_total` int(15) NOT NULL,
  `tgl_btb` varchar(20) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `ket` varchar(500) NOT NULL,
  PRIMARY KEY (`id_nm`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `btb`
--

INSERT INTO `btb` (`id_nm`, `no_btb`, `no_sj`, `supplier`, `no_po`, `kode`, `kodebb`, `packing`, `sat`, `unit`, `tonage`, `hrg_sat`, `hrg_total`, `tgl_btb`, `kategori`, `ket`) VALUES
(2, 'BTB.14.10.00001', 'AS 223', 'BUMI DANA', 'PO.14.10.0001', 'XA001', 'XA001', 'Zak', 50, 2000, 100000, 300000, 600000000, '02-Okt-2014', 'Bahan Baku', '');

-- --------------------------------------------------------

--
-- Table structure for table `btbll`
--

CREATE TABLE IF NOT EXISTS `btbll` (
  `id_nm` int(10) NOT NULL,
  `no_btbll` varchar(10) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `kodebb` varchar(50) NOT NULL,
  `tonage` int(10) NOT NULL,
  `tgl_btbll` varchar(20) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `ket` varchar(500) NOT NULL,
  PRIMARY KEY (`id_nm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `btbll`
--


-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `id_k` int(20) NOT NULL,
  `id_m` varchar(20) NOT NULL,
  `waktu_k` varchar(40) NOT NULL,
  `komentar` text NOT NULL,
  `pengirim_k` varchar(30) NOT NULL,
  PRIMARY KEY (`id_k`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `komentar`
--


-- --------------------------------------------------------

--
-- Table structure for table `masalah`
--

CREATE TABLE IF NOT EXISTS `masalah` (
  `id_nm` int(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `id_s` varchar(10) NOT NULL,
  `jam` varchar(20) NOT NULL,
  `tanggal` varchar(20) NOT NULL,
  `masalah` text NOT NULL,
  PRIMARY KEY (`id_nm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masalah`
--


-- --------------------------------------------------------

--
-- Table structure for table `master_barang`
--

CREATE TABLE IF NOT EXISTS `master_barang` (
  `id` int(11) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `kodebb` varchar(50) NOT NULL,
  `packing` varchar(50) NOT NULL,
  `sat` int(4) NOT NULL,
  `isi` int(4) NOT NULL,
  `hrg_sat` int(15) NOT NULL,
  `smin` int(5) NOT NULL,
  `rop` int(5) NOT NULL,
  `smax` int(5) NOT NULL,
  `supplier` varchar(50) NOT NULL,
  `LT` varchar(20) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `ket` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_barang`
--

INSERT INTO `master_barang` (`id`, `kode`, `kodebb`, `packing`, `sat`, `isi`, `hrg_sat`, `smin`, `rop`, `smax`, `supplier`, `LT`, `kategori`, `ket`) VALUES
(5, 'DS10101005', 'DUS CTS GL', 'Pcs', 1, 4, 5000, 300, 400, 500, 'Kimu Enam PT', '3 Hari', 'Dus', ' '),
(4, 'DS101020105', 'DUS CTM GL', 'Pcs', 1, 4, 4000, 200, 300, 500, 'JATI MEKAR ', '3 Hari', 'Dus', ' '),
(3, 'KM10101005', 'CONT CTS GL', 'Pcs', 1, 0, 10000, 200, 300, 500, 'SAN DARMA PT', '3 Hari', 'Kemasan', ' '),
(2, 'KM10101025', 'CONT CTS PL', 'Pcs', 1, 0, 15000, 1000, 2000, 3000, 'MULTI MAKMUR', '3 Hari', 'Kemasan', ' '),
(1, 'KM101020105', 'CONT CTM GL', 'Pcs', 1, 0, 10000, 200, 300, 500, 'SAN DARMA PT', '3 Hari', 'Kemasan', ' '),
(6, 'XA001', 'XA001', 'Zak', 50, 0, 300000, 1000, 1200, 1500, 'BUMI DANA', '3 Hari', 'Bahan Baku', ' '),
(7, 'XA002', 'XA002', 'Zak', 40, 0, 250000, 2000, 3000, 5000, 'BUMI DANA', '5 Hari', 'Bahan Baku', ' ');

-- --------------------------------------------------------

--
-- Table structure for table `master_produk`
--

CREATE TABLE IF NOT EXISTS `master_produk` (
  `nm_prod` varchar(50) NOT NULL,
  `kode_jprod` varchar(50) NOT NULL,
  `kodebb_jp` varchar(20) NOT NULL,
  `ket` varchar(500) NOT NULL,
  PRIMARY KEY (`nm_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_produk`
--

INSERT INTO `master_produk` (`nm_prod`, `kode_jprod`, `kodebb_jp`, `ket`) VALUES
('ARCA', '1151206', 'WRA', ''),
('BRILLO', '1081401', 'CKB', ''),
('DISNILUX', '1020401', 'CGD', ''),
('ESTIMA', '10110325', 'CTES', ''),
('INULEX', '1011401', 'CTI', ''),
('MARITEX', '1010201', 'CTM', ''),
('MAXEECOAT', '1010603', 'CTMC', ''),
('PREMIO COMPLETA', '10117032', 'CTPRMC', ''),
('PREMIO EXTERA', '1011702', 'CTPRME', ''),
('RABBIT', '1010501', 'CTR', ''),
('SANLEX', '101010', 'CTS', ''),
('SENDAI', '1080101', 'CKS', ''),
('TULIP', '1011301', 'CTT', '');

-- --------------------------------------------------------

--
-- Table structure for table `master_supplier`
--

CREATE TABLE IF NOT EXISTS `master_supplier` (
  `supplier` varchar(50) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `attn` varchar(20) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `ket` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_supplier`
--

INSERT INTO `master_supplier` (`supplier`, `no_telp`, `email`, `alamat`, `attn`, `kategori`, `ket`) VALUES
('BUKIT ASAR', '022-695-879-548', 'bukit asar@yahoo.com', 'Bogor', 'Bpk Hartono', 'Bahan Baku', ''),
('BUMI DANA', '022-568-968-548', 'bumidana@gmail.com', 'Surabaya', 'Bu Pelicia', 'Bahan Baku', ''),
('JATI MEKAR ', '022-568-897-854', 'jatimekarbox@gmail.com', 'JL Jurang no 25 Bandung', 'Bpk Hary', 'Dus', ''),
('JAVA ENGINERING', '022-897-568-945', 'jaeng@gmail.com', 'Semarang', 'Ibu Anita', 'Bahan Baku', ''),
('Kimu Enam PT', '02256879564', 'kimu@gmail.com', 'Jl Cihanjuang no 11', 'Bu Laudiya', 'Dus', ''),
('MULTI MAKMUR', '022-564-785-212', 'multimakmur@yahoo.com', 'Surabaya', 'Ibu Diana', 'Kemasan', ''),
('NUPLAST PT', '022-587-965-428', 'nuplast@gmail.com', 'Jl Rancaekek no 20 Bandung ', 'Bu Andini', 'Kemasan', ''),
('POP CAN PT', '0235628235', 'popcan@gmail.com', 'Surabaya', 'bu Tati', 'Kemasan', 'Cash'),
('SAN DARMA PT', '02263775685', 'sandarma@gmail.com', 'Jl. Ahmad Yani', 'Pa Hary', 'Kemasan', ''),
('SANTO PLASTIK', '022-6758-968-54', 'santoplastik@ymail.com', 'JL Industri 2 no 1 Leuwi Gajah Cimahi', 'Bpk Sandi', 'Kemasan', ''),
('SURYA BUANA', '022-589-879-658', 'suryabuana@yahoo.com', 'JL Ujung Berung no 18 Bandung', 'Bu Gress', 'Dus', ''),
('TERATAI PLASTIK', '022-879-457-865', 'teratai@gmail.com', 'Jl Cihanjuang no 05 Cimahi Bandung', 'Bu Imas', 'Kemasan', '');

-- --------------------------------------------------------

--
-- Table structure for table `po`
--

CREATE TABLE IF NOT EXISTS `po` (
  `id_nm` int(10) NOT NULL AUTO_INCREMENT,
  `no_po` varchar(20) NOT NULL,
  `supplier` varchar(50) NOT NULL,
  `no_ppb` varchar(20) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `kodebb` varchar(50) NOT NULL,
  `packing` varchar(10) NOT NULL,
  `sat` int(4) NOT NULL,
  `unit` int(10) NOT NULL,
  `hrg_sat` int(15) NOT NULL,
  `hrg_total` int(20) NOT NULL,
  `tgl_po` varchar(20) NOT NULL,
  `tgl_kirim` varchar(20) NOT NULL,
  `po_datang` int(10) NOT NULL,
  `sisa_po` int(10) NOT NULL,
  `attn` varchar(20) NOT NULL,
  `po_untuk` varchar(50) NOT NULL,
  `kirim_ke` varchar(50) NOT NULL,
  `kategori` varchar(10) NOT NULL DEFAULT '',
  `ket` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_nm`),
  UNIQUE KEY `no_po` (`no_po`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `po`
--

INSERT INTO `po` (`id_nm`, `no_po`, `supplier`, `no_ppb`, `kode`, `kodebb`, `packing`, `sat`, `unit`, `hrg_sat`, `hrg_total`, `tgl_po`, `tgl_kirim`, `po_datang`, `sisa_po`, `attn`, `po_untuk`, `kirim_ke`, `kategori`, `ket`) VALUES
(1, 'PO.14.10.0001', 'BUMI DANA', 'PPB.14.10.00001', 'XA001', 'XA001', 'Zak', 50, 2000, 300000, 600000000, '02-Okt-2014', '06-10-2014', 2000, 0, 'Bu A', 'RH', 'Pabrik', 'Bahan Baku', '');

-- --------------------------------------------------------

--
-- Table structure for table `ppb`
--

CREATE TABLE IF NOT EXISTS `ppb` (
  `id_nm` int(10) NOT NULL,
  `no_ppb` varchar(25) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `kodebb` varchar(50) NOT NULL,
  `packing` varchar(20) NOT NULL,
  `sat` int(4) NOT NULL,
  `unit` int(10) NOT NULL,
  `tonage` int(20) NOT NULL,
  `tgl_ppb` varchar(20) NOT NULL,
  `jthtmpo_ppb` varchar(20) NOT NULL,
  `no_po` varchar(20) NOT NULL,
  `hrg_sat` int(15) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `tgl_ppb_batal` varchar(20) NOT NULL,
  `ket` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_nm`),
  UNIQUE KEY `no_ppb` (`no_ppb`),
  UNIQUE KEY `no_ppb_2` (`no_ppb`),
  UNIQUE KEY `no_ppb_3` (`no_ppb`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ppb`
--

INSERT INTO `ppb` (`id_nm`, `no_ppb`, `kode`, `kodebb`, `packing`, `sat`, `unit`, `tonage`, `tgl_ppb`, `jthtmpo_ppb`, `no_po`, `hrg_sat`, `kategori`, `status`, `tgl_ppb_batal`, `ket`) VALUES
(1, 'PPB.14.10.00001', 'XA001', 'XA001', 'Zak', 50, 2000, 100000, '02-Okt-2014', '06-10-2014', 'PO.14.10.0001', 300000, 'Bahan Baku', '', '', ''),
(2, 'PPB.14.10.00002', 'KM10101025', 'CONT CTS PL', 'Pcs', 1, 500, 500, '02-Okt-2014', '06-10-2014', '', 15000, 'Kemasan', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ppb_batal`
--

CREATE TABLE IF NOT EXISTS `ppb_batal` (
  `id_nm` int(10) NOT NULL AUTO_INCREMENT,
  `no_ppb` varchar(25) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `kodebb` varchar(20) NOT NULL,
  `packing` varchar(20) NOT NULL,
  `sat` int(4) NOT NULL,
  `unit` int(10) NOT NULL,
  `tonage` int(20) NOT NULL,
  `tgl_ppb` varchar(20) NOT NULL,
  `jthtmpo_ppb` varchar(20) NOT NULL,
  `hrg_sat` int(15) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `tgl_ppb_batal` varchar(20) NOT NULL,
  `ket` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_nm`),
  UNIQUE KEY `no_ppb` (`no_ppb`),
  UNIQUE KEY `no_ppb_2` (`no_ppb`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ppb_batal`
--


-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `jk` varchar(12) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jabatan` varchar(20) NOT NULL,
  `image` varchar(100) NOT NULL,
  `ket` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`username`, `password`, `nama`, `no_telp`, `email`, `jk`, `agama`, `alamat`, `jabatan`, `image`, `ket`) VALUES
('Aef', 'aef', 'Aef', '', '', '', '', 'Cibodas', 'Adm Produksi', '../profile/1150794_598981853458502_1389366015_n.jpg', ''),
('Andi Rohandi', 'andi', 'Andi Rohandi', '', '', '', '', 'Jl. Cibaligo Timur', 'Staff Adm (Inv Scm)', '../profile/Kimbap6443.jpg', ''),
('Asti', 'asti', 'Asti', '', '', '', '', 'Jl. Leuwi Gajah', 'Staff Adm (WH)', '../profile/1003340_10153054240485008_2121454989_n.jpg', ''),
('Ejang Nurjaman', 'ejang', 'Ejang Nurjaman', '', '', '', '', 'Jl. Setia Budi', 'Staff Adm (WH)', '../profile/ejang.jpg	\r\n\r\n', ''),
('Haerini', 'rini', 'Haerini', '', '', '', '', 'Jl. Ahmad Yani', 'Staff Adm (Purch)', '../profile/rini.jpg', ''),
('Irma Iryani', 'irma', 'Irma Iryani', '089690428088', 'irma@gmail.com', 'Perempuan', 'ISLAM', 'Jl. Cisarua Bandung', '', '../profile/dress muslimah terbaru Balimo Neysha LC warna baby blue full_20131010162955.jpg', ''),
('Siti Rahmawati Ramadhani', 'siti', 'Siti Rahmawati R', '089690428088', 'andicangkir@gmail.com', 'Perempuan', 'ISLAM', 'JL Jurang no 25 Bandung', '', '../profile/rahma.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `retur_prod`
--

CREATE TABLE IF NOT EXISTS `retur_prod` (
  `id_nm` int(10) NOT NULL,
  `no_ret` varchar(20) NOT NULL,
  `no_val` varchar(20) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `kodebb` varchar(50) NOT NULL,
  `sat` int(4) NOT NULL,
  `unit` int(20) NOT NULL,
  `tonage` int(15) NOT NULL,
  `no_bkb` varchar(20) NOT NULL,
  `tgl_ret` varchar(20) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `ket` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `retur_prod`
--

INSERT INTO `retur_prod` (`id_nm`, `no_ret`, `no_val`, `kode`, `kodebb`, `sat`, `unit`, `tonage`, `no_bkb`, `tgl_ret`, `kategori`, `ket`) VALUES
(1, 'RTP.14.10.0001', '', 'XA001', 'XA001', 50, 800, 40000, 'BKB.14.10.0001', '02-Okt-2014', 'Bahan Baku', ''),
(2, 'RTP.14.10.0002', '', 'XA001', 'XA001', 50, 200, 10000, 'BKB.14.10.0001', '02-Okt-2014', 'Bahan Baku', '');

-- --------------------------------------------------------

--
-- Table structure for table `retur_sup`
--

CREATE TABLE IF NOT EXISTS `retur_sup` (
  `id_nm` int(10) NOT NULL,
  `no_ret` varchar(10) NOT NULL,
  `tgl_ret` varchar(20) NOT NULL,
  `no_btb` varchar(10) NOT NULL,
  `no_po` varchar(20) NOT NULL,
  `supplier` varchar(50) NOT NULL,
  `no_sj` varchar(20) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `kodebb` varchar(50) NOT NULL,
  `packing` varchar(10) NOT NULL,
  `sat` int(4) NOT NULL,
  `unit` int(10) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `ket` varchar(500) NOT NULL,
  PRIMARY KEY (`id_nm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `retur_sup`
--


-- --------------------------------------------------------

--
-- Table structure for table `solusi`
--

CREATE TABLE IF NOT EXISTS `solusi` (
  `id_s` int(10) NOT NULL,
  `id_ms` int(10) NOT NULL,
  `jam_s` varchar(10) NOT NULL,
  `tanggal_s` varchar(20) NOT NULL,
  `solusi` text NOT NULL,
  PRIMARY KEY (`id_s`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `solusi`
--


-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `id_nm` int(10) NOT NULL,
  `pengirim` varchar(50) NOT NULL,
  `waktu` varchar(40) NOT NULL,
  `masalah` text NOT NULL,
  PRIMARY KEY (`id_nm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--


-- --------------------------------------------------------

--
-- Table structure for table `stock_barang`
--

CREATE TABLE IF NOT EXISTS `stock_barang` (
  `kode` varchar(100) NOT NULL,
  `kodebb` varchar(100) NOT NULL,
  `packing` varchar(10) NOT NULL,
  `sat` int(4) NOT NULL,
  `s_awal` int(10) NOT NULL,
  `masuk` int(10) NOT NULL,
  `keluar` int(10) NOT NULL,
  `adjust` int(10) NOT NULL,
  `s_akhir` int(15) NOT NULL,
  `smin` int(10) NOT NULL,
  `rop` int(10) NOT NULL,
  `smax` int(10) NOT NULL,
  `st_smin` int(15) NOT NULL,
  `kategori` varchar(10) NOT NULL,
  `ket` varchar(500) NOT NULL,
  PRIMARY KEY (`kode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_barang`
--

INSERT INTO `stock_barang` (`kode`, `kodebb`, `packing`, `sat`, `s_awal`, `masuk`, `keluar`, `adjust`, `s_akhir`, `smin`, `rop`, `smax`, `st_smin`, `kategori`, `ket`) VALUES
('KM10101005', 'CONT CTS GL', 'Pcs', 1, 0, 0, 0, 0, 0, 200, 300, 500, 0, 'Kemasan', ''),
('DS101020105', 'DUS CTM GL', 'Pcs', 1, 0, 0, 0, 0, 0, 200, 300, 500, 0, 'Dus', ''),
('KM10101025', 'CONT CTS PL', 'Pcs', 1, 0, 0, 0, 0, 0, 1000, 2000, 3000, 0, 'Kemasan', ''),
('KM101020105', 'CONT CTM GL', 'Pcs', 1, 0, 0, 0, 0, 0, 200, 300, 500, 0, 'Kemasan', ''),
('DS10101005', 'DUS CTS GL', 'Pcs', 1, 0, 0, 0, 0, 0, 300, 400, 500, 0, 'Dus', ''),
('XA001', 'XA001', 'Zak', 50, 0, 2000, 200, 0, 1800, 1000, 2000, 3000, 0, 'Bahan Baku', ''),
('XA002', 'XA002', 'Zak', 40, 0, 0, 0, 0, 0, 2000, 3000, 5000, 0, 'Bahan Baku', '');

-- --------------------------------------------------------

--
-- Table structure for table `val_bkb`
--

CREATE TABLE IF NOT EXISTS `val_bkb` (
  `id_nm` int(10) NOT NULL AUTO_INCREMENT,
  `no_val` varchar(20) NOT NULL,
  `no_bkb` varchar(20) NOT NULL,
  `tgl_val` varchar(20) NOT NULL,
  PRIMARY KEY (`id_nm`),
  UNIQUE KEY `no_val` (`no_val`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `val_bkb`
--


-- --------------------------------------------------------

--
-- Table structure for table `val_ret`
--

CREATE TABLE IF NOT EXISTS `val_ret` (
  `id_nm` int(11) NOT NULL,
  `no_val` varchar(20) NOT NULL,
  `no_ret_v` varchar(20) NOT NULL,
  `tgl_val` varchar(20) NOT NULL,
  PRIMARY KEY (`id_nm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `val_ret`
--

